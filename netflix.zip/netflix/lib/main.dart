import 'package:flutter/material.dart';
//import 'package:netflix/screen/homepage.dart';
import 'package:netflix/shared/widget/bottomnavigation.dart';

void main() {
  runApp(MaterialApp(
      //home: HomePage()
      home: NavBar()));
}
