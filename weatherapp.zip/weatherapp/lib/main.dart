import 'package:flutter/material.dart';
import 'package:weather/screen/homepage.dart';

void main() {
  runApp(const MaterialApp(
    home: HomePage(),
  ));
}
