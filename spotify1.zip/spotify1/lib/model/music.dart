class Music {
  String name;
  String image;
  String desc;
  String audioURL;
  Music(this.name, this.image, this.desc, this.audioURL);
}
